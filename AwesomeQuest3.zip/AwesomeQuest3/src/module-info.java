/**
 * 
 */
/**
 * @author thesi
 *
 */
module AwesomeQuest3 {
	requires java.desktop;
}