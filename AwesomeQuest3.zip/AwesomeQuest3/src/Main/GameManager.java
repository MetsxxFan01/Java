package Main;

public class GameManager {
	
	UI ui = new UI(this);

	public static void main(String[] args) {
		
		new GameManager();
		
	}
	public GameManager() {
		
	}

}
